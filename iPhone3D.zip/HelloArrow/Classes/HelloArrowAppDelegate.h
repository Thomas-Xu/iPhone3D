#import "GLView.h"

@interface HelloArrowAppDelegate : NSObject <UIApplicationDelegate> {
@private
    UIWindow* m_window;
    GLView* m_view;
}

@end

