#include "GLView.h"

@interface TouchConeAppDelegate : NSObject <UIApplicationDelegate> {
@private
    UIWindow* m_window;
    GLView* m_view;
}

@end

