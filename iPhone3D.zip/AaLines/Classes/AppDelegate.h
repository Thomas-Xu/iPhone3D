#include "GLView.h"

@interface AppDelegate : NSObject <UIApplicationDelegate> {
@private
    UIWindow* m_window;
    GLView* m_view;
}

@end

