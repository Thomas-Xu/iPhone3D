#include "GLView.h"

@interface HelloConeAppDelegate : NSObject <UIApplicationDelegate> {
@private
    UIWindow* m_window;
    GLView* m_view;
}

@end

